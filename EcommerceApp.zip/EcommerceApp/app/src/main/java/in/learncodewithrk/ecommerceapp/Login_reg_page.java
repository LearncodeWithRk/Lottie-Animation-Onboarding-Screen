package in.learncodewithrk.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Login_reg_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_reg_page);
    }
}